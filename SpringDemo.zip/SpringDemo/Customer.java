package SpringDemo;

public class Customer {
	
	private int customerId;
	private String customerName;
	private String coustomerAddress;
	
	public Customer() {
		
	}

	public Customer(int customerId, String customerName, String coustomerAddress) {
		super();
		this.customerId = customerId;
		this.customerName = customerName;
		this.coustomerAddress = coustomerAddress;
	}

	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", customerName=" + customerName + ", coustomerAddress="
				+ coustomerAddress + "]";
	}

}

package com.fusion;

public class Department {

	private int DepartmentId;
	private String DepartementName;
	
	public Department() {
		// TODO Auto-generated constructor stub
	}

	public Department(int departmentId, String departementName) {
		super();
		DepartmentId = departmentId;
		DepartementName = departementName;
	}

	@Override
	public String toString() {
		return "Department [DepartmentId=" + DepartmentId + ", DepartementName=" + DepartementName + "]";
	}
	
	
	
}

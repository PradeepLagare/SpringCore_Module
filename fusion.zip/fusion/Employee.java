package com.fusion;

public class Employee {
	
	private int EmployeeId;
	private String EmployeeName;
	private String EmployeeRole;
	private double EmployeeSalary;
	
	private Department department;
	
	public Employee() {
		
	}

	

	public Employee(int employeeId, String employeeName, String employeeRole, double employeeSalary,
			Department department) {
		super();
		EmployeeId = employeeId;
		EmployeeName = employeeName;
		EmployeeRole = employeeRole;
		EmployeeSalary = employeeSalary;
		this.department = department;
	}



	@Override
	public String toString() {
		return "Employee [EmployeeId=" + EmployeeId + ", EmployeeName=" + EmployeeName + ", EmployeeRole="
				+ EmployeeRole + ", EmployeeSalary=" + EmployeeSalary + ", department=" + department + "]";
	}




	

}

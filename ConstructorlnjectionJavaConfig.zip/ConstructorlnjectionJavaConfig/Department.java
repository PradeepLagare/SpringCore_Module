package ConstructorlnjectionJavaConfig;

public class Department {

	private int DepartmentId;
	private String DepartementName;
	
	
	
	public Department(int departmentId, String departementName) {
		super();
		DepartmentId = departmentId;
		DepartementName = departementName;
	}



	@Override
	public String toString() {
		return "Department [DepartmentId=" + DepartmentId + ", DepartementName=" + DepartementName + "]";
	}
	
	
	
	
	
	
}
